﻿using System.Reflection;

[assembly: AssemblyCompany("MonoSandbox")]
[assembly: AssemblyConfiguration("Debug")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0")]
[assembly: AssemblyProduct("MonoSandbox")]
[assembly: AssemblyTitle("MonoSandbox")]
[assembly: AssemblyVersion("1.0.0.0")]
