﻿// Decompiled with JetBrains decompiler
// Type: MonoSandbox.RefCache
// Assembly: MonoSandbox, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: E9715068-C229-4EA2-B292-9AF3D905BE89
// Assembly location: C:\Program Files (x86)\Steam\steamapps\common\Gorilla Tag\BepInEx\plugins\MonoSandbox.dll

using UnityEngine;

#nullable disable
namespace MonoSandbox
{
  public static class RefCache
  {
    public static GameObject LHand;
    public static GameObject RHand;
    public static GameObject SandboxContainer;
    public static bool HitExists;
    public static RaycastHit Hit;
    public static Material Default;
    public static Material Selection;
    public static AudioClip PageSelection;
    public static AudioClip ItemSelection;
  }
}
