﻿// Decompiled with JetBrains decompiler
// Type: MonoSandbox.PluginInfo
// Assembly: MonoSandbox, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: E9715068-C229-4EA2-B292-9AF3D905BE89
// Assembly location: C:\Program Files (x86)\Steam\steamapps\common\Gorilla Tag\BepInEx\plugins\MonoSandbox.dll

#nullable disable
namespace MonoSandbox
{
  public class PluginInfo
  {
    public const string GUID = "goldentrophy.monosphere.dev.monosandbox";
    public const string Name = "MonoSandbox";
    public const string Version = "1.2.4";
  }
}
